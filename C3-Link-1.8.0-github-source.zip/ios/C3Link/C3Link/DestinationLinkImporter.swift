import Foundation

enum ExternalMapProvider {
    case googleMaps
    case waze
}

enum ImportedDestination {
    case coordinate(latitude: Double, longitude: Double, label: String)
    case search(String)
}

enum DestinationImportError: LocalizedError {
    case emptyClipboard
    case unsupportedLink

    var errorDescription: String? {
        switch self {
        case .emptyClipboard:
            return "Copie primeiro o link do destino no Google Maps ou Waze"
        case .unsupportedLink:
            return "Não encontrei o destino nesse link. Copie o link do local exato e tente novamente"
        }
    }
}

/** Resolves shared Google Maps and Waze links without a paid Places API key. */
final class DestinationLinkImporter {
    private let session: URLSession

    init() {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 18
        configuration.waitsForConnectivity = true
        session = URLSession(configuration: configuration)
    }

    func resolve(_ clipboardText: String) async throws -> ImportedDestination {
        let text = clipboardText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { throw DestinationImportError.emptyClipboard }
        guard let originalURL = URL(string: text),
              let scheme = originalURL.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else {
            return .search(text)
        }

        if let destination = extract(from: originalURL) { return destination }

        var request = URLRequest(url: originalURL)
        request.setValue(OpenNavigationService.userAgent, forHTTPHeaderField: "User-Agent")
        do {
            let (_, response) = try await session.data(for: request)
            if let finalURL = response.url,
               let destination = extract(from: finalURL) {
                return destination
            }
        } catch {
            // The original URL can still contain a usable text query below.
        }

        if let query = searchQuery(from: originalURL) { return .search(query) }
        throw DestinationImportError.unsupportedLink
    }

    private func extract(from url: URL) -> ImportedDestination? {
        let absolute = url.absoluteString.removingPercentEncoding ?? url.absoluteString
        let label = destinationLabel(from: url)

        if let captures = captures(
            pattern: #"!3d(-?\d+(?:\.\d+)?)!4d(-?\d+(?:\.\d+)?)"#,
            text: absolute
        ), let latitude = Double(captures[0]), let longitude = Double(captures[1]),
           valid(latitude, longitude) {
            return .coordinate(latitude: latitude, longitude: longitude, label: label)
        }

        if let components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            for key in ["ll", "center", "query", "q", "destination", "daddr"] {
                if let value = components.queryItems?.first(where: { $0.name.lowercased() == key })?.value,
                   let coordinate = coordinate(from: value) {
                    return .coordinate(
                        latitude: coordinate.latitude,
                        longitude: coordinate.longitude,
                        label: label
                    )
                }
            }
        }

        if let captures = captures(
            pattern: #"@(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)"#,
            text: absolute
        ), let latitude = Double(captures[0]), let longitude = Double(captures[1]),
           valid(latitude, longitude) {
            return .coordinate(latitude: latitude, longitude: longitude, label: label)
        }

        if let query = searchQuery(from: url) { return .search(query) }
        return nil
    }

    private func coordinate(from value: String) -> (latitude: Double, longitude: Double)? {
        guard let values = captures(
            pattern: #"(-?\d{1,2}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)"#,
            text: value
        ), let latitude = Double(values[0]), let longitude = Double(values[1]),
           valid(latitude, longitude) else { return nil }
        return (latitude, longitude)
    }

    private func searchQuery(from url: URL) -> String? {
        if let components = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            for key in ["query", "q", "destination", "daddr"] {
                guard let raw = components.queryItems?.first(where: { $0.name.lowercased() == key })?.value else {
                    continue
                }
                let value = cleaned(raw)
                if coordinate(from: value) == nil, value.count >= 3 { return value }
            }
        }

        let parts = url.pathComponents.filter { $0 != "/" }
        if let placeIndex = parts.firstIndex(where: { $0.lowercased() == "place" }),
           parts.indices.contains(placeIndex + 1) {
            let value = cleaned(parts[placeIndex + 1])
            if value.count >= 3 { return value }
        }
        return nil
    }

    private func destinationLabel(from url: URL) -> String {
        if let query = searchQuery(from: url) { return query }
        let host = url.host?.lowercased() ?? ""
        return host.contains("waze") ? "Destino do Waze" : "Destino do Google Maps"
    }

    private func cleaned(_ value: String) -> String {
        (value.removingPercentEncoding ?? value)
            .replacingOccurrences(of: "+", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func valid(_ latitude: Double, _ longitude: Double) -> Bool {
        latitude.isFinite && longitude.isFinite &&
            (-90.0...90.0).contains(latitude) && (-180.0...180.0).contains(longitude)
    }

    private func captures(pattern: String, text: String) -> [String]? {
        guard let expression = try? NSRegularExpression(pattern: pattern),
              let match = expression.firstMatch(
                in: text,
                range: NSRange(text.startIndex..., in: text)
              ), match.numberOfRanges >= 3 else { return nil }
        let values = (1...2).compactMap { index -> String? in
            guard let range = Range(match.range(at: index), in: text) else { return nil }
            return String(text[range])
        }
        return values.count == 2 ? values : nil
    }
}

# C3 Link 1.8.1 para iPhone

Companheiro da C3 Media 1.8.1. Sugere destinos enquanto o usuário digita, entende mensagens e links copiados do Google Maps/Waze, mostra a rota inteira em um mapa interativo no iPhone, mantém GPS autorizado em segundo plano e envia ao tablet rota, posição, instruções visuais e os tiles necessários. A rota usa partes pequenas com confirmação e reenvio automático. Não captura a tela, não imita CarPlay e não contém voz de GPS.

## Build local no macOS

```bash
brew install xcodegen
cd ios/C3Link
xcodegen generate
xcodebuild \
  -project C3Link.xcodeproj \
  -scheme C3Link \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO \
  build
```

## Build pelo Windows

Use o workflow `.github/workflows/ios-c3-link.yml` no GitHub Actions. Ele testa e compila em um executor macOS e entrega `C3-Link-1.8.1-unsigned.ipa`. No Windows, assine e instale o arquivo com Sideloadly.

## Uso

1. Instale a C3 Media 1.8.1 no tablet.
2. Conecte o iPhone à rede `Citroen-C3` com IP manual e roteador vazio.
3. Abra o C3 Link, permita Rede local e Localização Sempre.
4. Procure um destino e escolha o resultado.
5. Confira a rota no mapa interativo, aguarde “Rota azul confirmada no tablet” e bloqueie o iPhone.
6. Para música, selecione **Citroën C3** no cartão de áudio AirPlay; não é necessário espelhar a tela.

Consulte `docs/INSTALLATION.md` e `docs/C3-LINK.md` na raiz do projeto.

import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var navigation: NavigationManager
    @State private var showingSettings = false

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 18) {
                    header
                    TransportStatusCard(transport: navigation.transport)
                    gpsStatus
                    destinationSection
                    searchResults
                    routeCard
                    audioCard

                    Text("O C3 Link usa OpenStreetMap para as ruas e calcula sua própria rota. Ele não copia nem modifica o Waze. A tela do iPhone pode ficar bloqueada durante uma navegação iniciada aqui.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.leading)
                }
                .padding()
            }
            .navigationTitle("C3 Link")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showingSettings = true } label: {
                        Image(systemName: "gearshape.fill")
                    }
                    .accessibilityLabel("Ajustes avançados")
                }
            }
            .sheet(isPresented: $showingSettings) { AdvancedSettingsView() }
        }
    }

    private var header: some View {
        VStack(spacing: 7) {
            Image(systemName: "car.side.fill")
                .font(.system(size: 48))
                .foregroundStyle(.red)
            Text("C3 LINK")
                .font(.system(size: 28, weight: .black, design: .rounded))
            Text("Mapa no tablet com o iPhone bloqueado")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding(.top, 8)
    }

    private var gpsStatus: some View {
        Label(navigation.locationStatus, systemImage: "location.fill")
            .font(.footnote.bold())
            .foregroundStyle(navigation.locationStatus.contains("Sempre") || navigation.locationStatus.contains("ativo") ? .green : .orange)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var destinationSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Destino")
                .font(.headline)
            TextField("Rua, número, cidade ou lugar", text: $navigation.destinationQuery)
                .textInputAutocapitalization(.words)
                .submitLabel(.search)
                .padding(14)
                .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
                .onSubmit { navigation.searchDestination() }

            if navigation.isNavigating {
                Button(role: .destructive) { navigation.stopNavigation() } label: {
                    Label("Encerrar navegação", systemImage: "stop.circle.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
            } else {
                Button { navigation.searchDestination() } label: {
                    HStack {
                        if navigation.isSearching { ProgressView().tint(.white) }
                        Label(navigation.isSearching ? "Procurando…" : "Procurar destino", systemImage: "magnifyingglass")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .disabled(
                    navigation.destinationQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
                        navigation.isSearching
                )
            }

            if navigation.isCalculating || navigation.isRecalculating {
                HStack(spacing: 9) {
                    ProgressView()
                    Text(navigation.isRecalculating ? "Recalculando rota…" : "Calculando rota…")
                        .font(.footnote.bold())
                }
            }

            if !navigation.errorMessage.isEmpty {
                Text(navigation.errorMessage)
                    .font(.footnote.bold())
                    .foregroundStyle(.red)
            }
        }
    }

    @ViewBuilder
    private var searchResults: some View {
        if !navigation.searchResults.isEmpty && !navigation.isNavigating {
            VStack(alignment: .leading, spacing: 8) {
                Text("Resultados")
                    .font(.headline)
                ForEach(navigation.searchResults) { result in
                    Button { navigation.startNavigation(to: result) } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "mappin.circle.fill")
                                .font(.title2)
                                .foregroundStyle(.red)
                            VStack(alignment: .leading, spacing: 3) {
                                Text(result.title)
                                    .font(.body.bold())
                                    .foregroundStyle(.primary)
                                    .multilineTextAlignment(.leading)
                                if !result.subtitle.isEmpty {
                                    Text(result.subtitle)
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                        .lineLimit(2)
                                        .multilineTextAlignment(.leading)
                                }
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .foregroundStyle(.secondary)
                        }
                        .padding(12)
                        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 14))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    @ViewBuilder
    private var routeCard: some View {
        if navigation.isNavigating {
            VStack(alignment: .leading, spacing: 9) {
                Label("NAVEGAÇÃO VISUAL", systemImage: "map.fill")
                    .font(.caption.bold())
                    .foregroundStyle(.blue)
                Text(navigation.currentInstruction.isEmpty ? "Siga a rota" : navigation.currentInstruction)
                    .font(.title3.bold())
                Text(navigation.routeSummary)
                    .foregroundStyle(.secondary)
                Label("Agora você pode bloquear a tela do iPhone", systemImage: "lock.fill")
                    .font(.subheadline.bold())
                    .foregroundStyle(.green)
                Text("Sem voz de GPS: apenas o mapa e a música continuarão ativos.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(16)
            .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
        }
    }

    private var audioCard: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: "music.note")
                .font(.title2)
                .foregroundStyle(.red)
            VStack(alignment: .leading, spacing: 4) {
                Text("Música continua pelo AirPlay")
                    .font(.headline)
                Text("Mantenha Citroën C3 como saída de áudio. O caminho permanece iPhone → tablet → Bluetooth do rádio. O mapa não toma o lugar da música.")
                    .font(.footnote)
                    .foregroundStyle(.secondary)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(16)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct TransportStatusCard: View {
    @ObservedObject var transport: C3LinkTransport

    var body: some View {
        HStack(spacing: 12) {
            Circle()
                .fill(transport.isReady ? Color.green : Color.orange)
                .frame(width: 12, height: 12)
            VStack(alignment: .leading, spacing: 3) {
                Text(transport.isReady ? "Tablet conectado" : "Aguardando o tablet")
                    .font(.headline)
                Text(transport.statusText)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: transport.isReady ? "checkmark.icloud.fill" : "antenna.radiowaves.left.and.right")
                .foregroundStyle(transport.isReady ? .green : .orange)
        }
        .padding(16)
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct AdvancedSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage("c3link.search-endpoint") private var searchEndpoint = OpenNavigationService.defaultSearchEndpoint
    @AppStorage("c3link.routing-endpoint") private var routingEndpoint = OpenNavigationService.defaultRoutingEndpoint

    var body: some View {
        NavigationStack {
            Form {
                Section("Serviços de mapa") {
                    TextField("Busca", text: $searchEndpoint)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                    TextField("Rotas", text: $routingEndpoint)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                }
                Section {
                    Button("Restaurar serviços padrão") {
                        searchEndpoint = OpenNavigationService.defaultSearchEndpoint
                        routingEndpoint = OpenNavigationService.defaultRoutingEndpoint
                    }
                } footer: {
                    Text("Esses endereços podem ser trocados se um servidor público estiver indisponível. As buscas só acontecem quando você toca em Procurar.")
                }
            }
            .navigationTitle("Ajustes avançados")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("OK") { dismiss() }
                }
            }
        }
    }
}

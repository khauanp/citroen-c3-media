import CoreLocation
import Foundation

enum NavigationServiceError: LocalizedError {
    case invalidEndpoint
    case invalidResponse
    case noDestination
    case noRoute

    var errorDescription: String? {
        switch self {
        case .invalidEndpoint: return "Endereço do serviço de mapas inválido"
        case .invalidResponse: return "O serviço de mapas respondeu de forma inválida"
        case .noDestination: return "Destino não encontrado"
        case .noRoute: return "Não foi possível calcular uma rota de carro"
        }
    }
}

final class OpenNavigationService {
    static let userAgent = "C3Link/2.0 (personal in-car navigation; https://github.com/khauanp/citroen-c3-media)"
    static let defaultSearchEndpoint = "https://nominatim.openstreetmap.org"
    static let defaultRoutingEndpoint = "https://router.project-osrm.org"

    private let session: URLSession
    private var lastSearchAt = Date.distantPast

    init() {
        let configuration = URLSessionConfiguration.default
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 35
        configuration.waitsForConnectivity = true
        configuration.requestCachePolicy = .useProtocolCachePolicy
        session = URLSession(configuration: configuration)
    }

    func search(query: String, near location: CLLocation?) async throws -> [DestinationResult] {
        // The public Nominatim service permits user-triggered searches, but asks
        // clients to stay at or below one request per second.
        let wait = 1.05 - Date().timeIntervalSince(lastSearchAt)
        if wait > 0 {
            try await Task.sleep(nanoseconds: UInt64(wait * 1_000_000_000))
        }
        lastSearchAt = Date()
        let defaults = UserDefaults.standard
        let endpoint = (defaults.string(forKey: "c3link.search-endpoint") ?? "").nilIfBlank
            ?? Self.defaultSearchEndpoint
        guard var components = URLComponents(string: endpoint + "/search") else {
            throw NavigationServiceError.invalidEndpoint
        }
        var items = [
            URLQueryItem(name: "q", value: query),
            URLQueryItem(name: "format", value: "jsonv2"),
            URLQueryItem(name: "addressdetails", value: "1"),
            URLQueryItem(name: "limit", value: "6"),
            URLQueryItem(name: "countrycodes", value: "br"),
            URLQueryItem(name: "accept-language", value: "pt-BR"),
        ]
        if let location {
            let delta = 1.2
            items.append(
                URLQueryItem(
                    name: "viewbox",
                    value: "\(location.coordinate.longitude - delta),\(location.coordinate.latitude + delta)," +
                        "\(location.coordinate.longitude + delta),\(location.coordinate.latitude - delta)"
                )
            )
        }
        components.queryItems = items
        guard let url = components.url else { throw NavigationServiceError.invalidEndpoint }
        var request = URLRequest(url: url)
        request.setValue(Self.userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("pt-BR,pt;q=0.9", forHTTPHeaderField: "Accept-Language")
        let (data, response) = try await session.data(for: request)
        try validate(response)
        let decoded = try JSONDecoder().decode([NominatimItem].self, from: data)
        let results = decoded.compactMap { item -> DestinationResult? in
            guard let latitude = Double(item.lat), let longitude = Double(item.lon) else { return nil }
            let display = item.displayName
            let firstComma = display.firstIndex(of: ",")
            let fallbackTitle = firstComma.map { String(display[..<$0]) } ?? display
            let title = (item.name ?? "").nilIfBlank ?? fallbackTitle
            let subtitle = display == title ? "" : display
            return DestinationResult(
                id: "\(item.placeId)-\(latitude)-\(longitude)",
                title: title,
                subtitle: subtitle,
                latitude: latitude,
                longitude: longitude
            )
        }
        if results.isEmpty { throw NavigationServiceError.noDestination }
        return results
    }

    func route(from origin: CLLocationCoordinate2D, to destination: DestinationResult) async throws -> NavigationRoute {
        let defaults = UserDefaults.standard
        let endpoint = (defaults.string(forKey: "c3link.routing-endpoint") ?? "").nilIfBlank
            ?? Self.defaultRoutingEndpoint
        let coordinates = "\(origin.longitude),\(origin.latitude);\(destination.longitude),\(destination.latitude)"
        guard var components = URLComponents(string: endpoint + "/route/v1/driving/" + coordinates) else {
            throw NavigationServiceError.invalidEndpoint
        }
        components.queryItems = [
            URLQueryItem(name: "overview", value: "full"),
            URLQueryItem(name: "geometries", value: "polyline"),
            URLQueryItem(name: "steps", value: "true"),
            URLQueryItem(name: "alternatives", value: "false"),
        ]
        guard let url = components.url else { throw NavigationServiceError.invalidEndpoint }
        var request = URLRequest(url: url)
        request.setValue(Self.userAgent, forHTTPHeaderField: "User-Agent")
        request.setValue("pt-BR,pt;q=0.9", forHTTPHeaderField: "Accept-Language")
        let (data, response) = try await session.data(for: request)
        try validate(response)
        let decoded = try JSONDecoder().decode(OSRMResponse.self, from: data)
        guard decoded.code == "Ok", let selected = decoded.routes.first else {
            throw NavigationServiceError.noRoute
        }
        var decodedCoordinates = PolylineEncoder.decode(selected.geometry, precision: 5)
        guard decodedCoordinates.count >= 2 else { throw NavigationServiceError.invalidResponse }

        var encoded = selected.geometry
        if decodedCoordinates.count > 1_200 || encoded.utf8.count > 8_000 {
            decodedCoordinates = PolylineEncoder.simplify(decodedCoordinates, maximumPoints: 1_200)
            encoded = PolylineEncoder.encode(decodedCoordinates, precision: 5)
        }
        var pointLimit = decodedCoordinates.count
        while encoded.utf8.count > 10_000 && pointLimit > 200 {
            pointLimit = max(200, pointLimit * 3 / 4)
            decodedCoordinates = PolylineEncoder.simplify(decodedCoordinates, maximumPoints: pointLimit)
            encoded = PolylineEncoder.encode(decodedCoordinates, precision: 5)
        }
        let steps = selected.legs.flatMap(\.steps).compactMap { step -> NavigationStep? in
            guard step.maneuver.location.count == 2 else { return nil }
            let coordinate = CLLocationCoordinate2D(
                latitude: step.maneuver.location[1],
                longitude: step.maneuver.location[0]
            )
            return NavigationStep(
                instruction: instruction(for: step),
                maneuver: maneuverKey(for: step),
                coordinate: coordinate,
                distanceMeters: step.distance,
                durationSeconds: step.duration
            )
        }
        return NavigationRoute(
            encodedPolyline: encoded,
            coordinates: decodedCoordinates,
            distanceMeters: selected.distance,
            durationSeconds: selected.duration,
            steps: steps
        )
    }

    private func validate(_ response: URLResponse) throws {
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            throw NavigationServiceError.invalidResponse
        }
    }

    private func maneuverKey(for step: OSRMStep) -> String {
        let modifier = step.maneuver.modifier ?? "straight"
        switch modifier {
        case "left", "slight left", "sharp left": return "left"
        case "right", "slight right", "sharp right": return "right"
        case "uturn": return "uturn"
        default:
            return step.maneuver.type.contains("roundabout") ? "roundabout" : "straight"
        }
    }

    private func instruction(for step: OSRMStep) -> String {
        let road = step.name.nilIfBlank.map { " na \($0)" } ?? ""
        let modifier = step.maneuver.modifier ?? "straight"
        switch step.maneuver.type {
        case "depart": return road.isEmpty ? "Inicie a rota" : "Siga\(road)"
        case "arrive": return "Você chegou ao destino"
        case "roundabout", "rotary":
            if let exit = step.maneuver.exit { return "Na rotatória, pegue a saída \(exit)\(road)" }
            return "Entre na rotatória\(road)"
        case "merge": return "Entre no fluxo\(road)"
        case "fork": return modifier.contains("left") ? "Mantenha-se à esquerda\(road)" : "Mantenha-se à direita\(road)"
        case "on ramp": return "Pegue o acesso\(road)"
        case "off ramp": return "Pegue a saída\(road)"
        case "continue", "new name": return "Continue\(road)"
        default:
            switch modifier {
            case "left": return "Vire à esquerda\(road)"
            case "slight left": return "Vire levemente à esquerda\(road)"
            case "sharp left": return "Faça uma curva fechada à esquerda\(road)"
            case "right": return "Vire à direita\(road)"
            case "slight right": return "Vire levemente à direita\(road)"
            case "sharp right": return "Faça uma curva fechada à direita\(road)"
            case "uturn": return "Faça o retorno\(road)"
            default: return road.isEmpty ? "Siga em frente" : "Siga\(road)"
            }
        }
    }
}

private struct NominatimItem: Decodable {
    let placeId: Int64
    let lat: String
    let lon: String
    let displayName: String
    let name: String?

    enum CodingKeys: String, CodingKey {
        case placeId = "place_id"
        case lat, lon, name
        case displayName = "display_name"
    }
}

private struct OSRMResponse: Decodable {
    let code: String
    let routes: [OSRMRoute]
}

private struct OSRMRoute: Decodable {
    let geometry: String
    let distance: Double
    let duration: Double
    let legs: [OSRMLeg]
}

private struct OSRMLeg: Decodable {
    let steps: [OSRMStep]
}

private struct OSRMStep: Decodable {
    let distance: Double
    let duration: Double
    let name: String
    let maneuver: OSRMManeuver
}

private struct OSRMManeuver: Decodable {
    let type: String
    let modifier: String?
    let location: [Double]
    let exit: Int?
}

private extension String {
    var nilIfBlank: String? {
        let value = trimmingCharacters(in: .whitespacesAndNewlines)
        return value.isEmpty ? nil : value
    }
}
